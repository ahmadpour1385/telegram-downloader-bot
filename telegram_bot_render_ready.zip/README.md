# Telegram Downloader Bot — Render Ready

This project is prepared for GitHub + Render deployment.

## Security
- The real `.env` file was intentionally NOT included.
- Never commit your real Telegram bot token.
- In Render, create an Environment Variable:
  - Key: `BOT_TOKEN`
  - Value: your real Telegram bot token

## Local development
1. Copy `.env.example` to `.env`
2. Put your real token in `.env`
3. Install dependencies:
   `pip install -r requirements.txt`
4. Make sure FFmpeg is installed and available in PATH.
5. Run:
   `python bot.py`

## Render
The included `Dockerfile` installs FFmpeg automatically.
The included `render.yaml` creates a background worker and asks Render for `BOT_TOKEN`.

## Important
`bot_data.pkl` is runtime persistence and is ignored by Git.
Without persistent storage, it can be lost when the service is recreated/redeployed.
